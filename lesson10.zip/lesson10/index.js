// 1-masala
// let obj ={
//     id : 1,
//     name : "WebBrain"
// }
//  for(let  key in obj){
// console.log((key));
//  }

// 2-masala

//  let obj = {
// id : 1,
// name : "Jaloliddin"
//  }
//  console.log("id : " +obj.id);

// 3-masala

// let obj ={
//     id : 1,
//     name : "Jaloliddin",
//     offline : true,
//     online : true,
//     individual : false
// }

// let obj1 = Object.assign({},obj)
// console.log(obj1);

// 4 - masala

// let person = {
//   id: 1,
//   Name: "Jaloliddin",
//   surname: "Karshiev",
//   Topik: 5,
//   student: true,
//   parol: 101,
// };

// function example() {
//   let bazadagiid = person.id;
//   let bazadaginame = person.Name;

//   if (bazadagiid === person.id && bazadaginame === person.Name) {
//     console.log("Xush kelipsiz!")
//   } else {
//     console.log("Login yoki parol xato")
//   }
// }

// example();
